# scrcpy工具仓库

> 本仓库使用版本：v1.18

- [scrcpy下载地址](https://github.com/Genymobile/scrcpy/releases/)

## Doc

- [scrcpy使用教程](https://github.com/Genymobile/scrcpy/blob/master/README.zh-Hans.md)