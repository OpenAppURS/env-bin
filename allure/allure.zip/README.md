# allure工具仓库

> 本仓库使用版本：v2.13.5

- [allure下载地址](https://github.com/allure-framework/allure2/releases/)

## Doc

- [allure使用教程](https://docs.qameta.io/allure/)