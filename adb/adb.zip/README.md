# adb & aapt工具仓库

> 本仓库使用版本
> - adb：v1.0.41
> - aapt: v0.2

- [adb(Platform Tools)下载地址](https://developer.android.com/studio/releases/platform-tools)
- [aapt下载地址](https://androidaapt.com/)

## Doc

- [adb使用教程1](https://github.com/mzlogin/awesome-adb)
- [adb使用教程2](https://adbinstaller.com/commands)
- [aapt使用教程](https://androidaapt.com/command)